<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="dash-home.css">
</head>
<body>
    <div class="px-2 bg-light"><marquee class="py-3 font-size-sm" scrollamount="5"><strong>Selamat Datang di Website Inventori Juragan Online Solusi</strong></marquee></div>
<div class="container ms-7" style="margin-top: 50px;">
    <div class="card">
        <div class="card-header">
            <h4>About Us</h4>
        </div>
        <div class="card-body">
            <img src="https://github.com/HandyAlek/image/blob/main/jos-removebg.png?raw=true" style="width: 200px; height: 200px; margin-right: 10px; margin-bottom: 40px; float: right">
            <p class="card-text mt-5">PT. Juragan Online Solusi merupakan perusahaan yang <br> bergerak di bidang ISP & Cloud, Colocation Managed Service <br> serta menyediakan layanan internet yaitu FTTH<br>
            <br>
            "Solusinya Para Juragan"</p>
        </div>
    </div>
</div>
</body>
</html>